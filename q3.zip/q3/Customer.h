#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include "CreditCard.h"
#include<memory>

using CreditPointer=std::shared_ptr<CreditCard>;
using RefCredit=std::reference_wrapper<CreditPointer>;

class Customer
{
private:
    std::string _id;
    std::string _name;
    int _age;
    RefCredit _credit_card;
public:
    Customer()=delete;
    Customer(const Customer&)=delete;
    Customer(const Customer&&)=delete;
    Customer& operator=(const Customer&)=delete;
    Customer& operator=(Customer&&)=delete;
    ~Customer()=default;

    Customer(std::string _id,std::string _name,int _age,RefCredit _credit_card);

    std::string id() const { return _id; }
    void setId(const std::string &id) { _id = id; }

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    int age() const { return _age; }
    void setAge(int age) { _age = age; }

    RefCredit creditCard() const { return _credit_card; }
    void setCreditCard(const RefCredit &credit_card) { _credit_card = credit_card; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);
};

#endif // CUSTOMER_H
