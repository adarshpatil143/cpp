#ifndef CREDITCARD_H
#define CREDITCARD_H

#include<iostream>
#include "CreditType.h"

class CreditCard
{
private:
    float _number;
    CreditType _type;
    int _max_limit;
public:
    CreditCard()=delete;
    CreditCard(const CreditCard&)=delete;
    CreditCard(const CreditCard&&)=delete;
    CreditCard& operator=(const CreditCard&)=delete;
    CreditCard& operator=(CreditCard&&)=delete;
    ~CreditCard()=default;

    CreditCard(float _number,CreditType _type,int _max_limit);

    float number() const { return _number; }
    void setNumber(float number) { _number = number; }

    CreditType type() const { return _type; }
    void setType(const CreditType &type) { _type = type; }

    int maxLimit() const { return _max_limit; }
    void setMaxLimit(int max_limit) { _max_limit = max_limit; }

    friend std::ostream &operator<<(std::ostream &os, const CreditCard &rhs);
};

std::string EnumDisplayCreditType(const CreditType&rhs);

#endif // CREDITCARD_H
