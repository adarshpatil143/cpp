#include "CreditCard.h"

CreditCard::CreditCard(float _number, CreditType _type, int _max_limit)
:_number(_number),_type(_type),_max_limit(_max_limit) {}

std::ostream &operator<<(std::ostream &os, const CreditCard &rhs) {
    os << "_number: " << rhs._number
       << " _type: " << EnumDisplayCreditType(rhs._type)
       << " _max_limit: " << rhs._max_limit;
    return os;
}

std::string EnumDisplayCreditType(const CreditType &rhs)
{
    if(rhs==CreditType::ELITE){
        return "ELITE";
    }else if(rhs==CreditType::PREMIUM){
        return "Premium";
    }else{
        return "Saving";
    }
}
