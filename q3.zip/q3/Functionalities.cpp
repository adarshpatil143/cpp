#include "Functionalities.h"




void CreateObjects(Container &data, ContainerCredit &cdata)
{
    cdata.push_back(std::make_shared<CreditCard>(123456,CreditType::ELITE,5000));
    cdata.push_back(std::make_shared<CreditCard>(123457,CreditType::ELITE,5000));
    cdata.push_back(std::make_shared<CreditCard>(123486,CreditType::SAVING,5600));
    cdata.push_back(std::make_shared<CreditCard>(123886,CreditType::PREMIUM,5000));

    data.emplace_back(std::make_shared<Customer>("a101","Raju",21,std::ref(cdata[0])));
    data.emplace_back(std::make_shared<Customer>("a102","Raju",20,std::ref(cdata[1])));
    data.emplace_back(std::make_shared<Customer>("a103","RajuBHai",22,std::ref(cdata[2])));
    data.emplace_back(std::make_shared<Customer>("a104","Raju",23,std::ref(cdata[3])));
}

void HigherOrderFun(Container &data, F1Type fn)
{
    fn(data);
}

void HigherOrderFun(Container &data, F2Type fn, float x)
{
    fn(data,x);
}
