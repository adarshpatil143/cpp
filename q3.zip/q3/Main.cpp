#include<iostream>
#include "CreditCard.h"
#include<memory>
#include "Customer.h"
#include<list>
#include<numeric>
#include<algorithm>
#include<vector>
#include "Functionalities.h"
#include<functional>
using namespace std::placeholders;



using CustomerPointer=std::shared_ptr<Customer>;
using Container=std::list<CustomerPointer>;
using ContainerCredit=std::vector<CreditPointer>;

using F1Type=std::function<void(Container&)>;
using F2Type=std::function<void(Container&,float)>;


int main(){
    Container data;
    ContainerCredit cdata;

    CreateObjects(data,cdata);

    auto f4=[](Container&data,float t){
        int c= std::count_if(
            data.begin(),
            data.end(),
            [&](const CustomerPointer&x){
                return t<x->creditCard().get()->maxLimit();
            }
        );
        std::cout<<"Count is :"<<c<<std::endl;

    };

    auto p4=std::bind(f4,_1,4.5);

    auto f5=[](Container&data,float age){
        std::cout<<"THe Cretit Types :"<<std::endl;
        std::for_each(
            data.begin(),
            data.end(),
            [&](const CustomerPointer&x){

                if(x->age()>age){
                    std::cout<<EnumDisplayCreditType(x->creditCard().get()->type())<<std::endl;
                }
            }
        );
    };

    auto p5=std::bind(f5,data,6.1);

    auto f6=[](Container&data){
        bool b=std::all_of(
            data.begin(),
            data.end(),
            [](const CustomerPointer&x){
                return (x->creditCard().get()->type()==CreditType::ELITE);
            }
        );
        if(b){
            std::cout<<"True"<<std::endl;
        }else{
            std::cout<<"False"<<std::endl;
        }
    };

    std::vector<F1Type> funs1{f6};
    std::vector<F2Type> funs2{p4,p5};

    for(auto&i:funs1){
        HigherOrderFun(data,i);
    }
    for(auto&i:funs2){
        HigherOrderFun(data,i,2.0f);
    }


}