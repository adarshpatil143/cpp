#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "CreditCard.h"
#include<memory>
#include "Customer.h"
#include<list>
#include<numeric>
#include<algorithm>
#include<vector>
#include<functional>



using CustomerPointer=std::shared_ptr<Customer>;
using Container=std::list<CustomerPointer>;
using ContainerCredit=std::vector<CreditPointer>;

using F1Type=std::function<void(Container&)>;
using F2Type=std::function<void(Container&,float)>;

/*
    A function create Objects
*/
void CreateObjects(Container&data,ContainerCredit&cdata);

/*
    A HIgher Order function 1
*/
void HigherOrderFun(Container&data,F1Type fn);

/*
    A HIgher Order function 2
*/
void HigherOrderFun(Container&data,F2Type fn,float x);

#endif // FUNCTIONALITIES_H
