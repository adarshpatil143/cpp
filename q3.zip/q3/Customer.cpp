#include "Customer.h"

Customer::Customer(std::string _id, std::string _name, int _age, RefCredit _credit_card)
:_id(_id),_name(_name),_age(_age),_credit_card(_credit_card) {}

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _age: " << rhs._age
       << " _credit_card: " << *rhs._credit_card.get();
    return os;
}

