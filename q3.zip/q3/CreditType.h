#ifndef CREDITTYPE_H
#define CREDITTYPE_H

enum class CreditType{
    PREMIUM,
    SAVING,
    ELITE
};

#endif // CREDITTYPE_H
