#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Permit.h"
#include "TouristVehicle.h"
#include "TouristVehicleType.h"
#include "PermitType.h"
#include<list>
#include<memory>
#include<numeric>
#include<algorithm>
#include<optional>

using PointerTourist = std::shared_ptr<TouristVehicle>;
using Container = std::list<PointerTourist>;

//Function for creating the object
void CreateObject(Container& data);

//Function to return the Conatainer of all instances of TouristVehicle which statisfy the condition
std::optional<Container> InstanceConditionSatisfy(Container& data);

//Function to find and return the average Tourist instance whose type is CAB
float AveragePerBooking(Container& data);

//Function to return Serial number of permit whose _per_booking_charge is maximum
std::string SerialOfMaxBookingCharge(Container& data);

//Function to return the first N instance of Tourist Vehicle
Container FirstNInstance(Container& data,int N);

#endif // FUNCTIONALITIES_H
