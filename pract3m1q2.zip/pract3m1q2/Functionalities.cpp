#include "Functionalities.h"

void CreateObject(Container& data)
{
    data.push_back(std::make_shared<TouristVehicle>("T101",TouristVehicleType::BIKE,2,500.0f,std::make_shared<Permit>("P101",PermitType::LEASE,2)));
    data.push_back(std::make_shared<TouristVehicle>("T202",TouristVehicleType::BUS,15,200.0f,std::make_shared<Permit>("P202",PermitType::LEASE,10)));
    data.push_back(std::make_shared<TouristVehicle>("T303",TouristVehicleType::CAB,4,2000.0f,std::make_shared<Permit>("P303",PermitType::OWNED,5)));
}

std::optional<Container> InstanceConditionSatisfy(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    Container result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [](const PointerTourist& pt) {
            return pt->seatCount() >= 4 && pt->permit().get()->permitType() == PermitType::LEASE;
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }

    return result;
}

float AveragePerBooking(Container &data)
{
    int count =0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total=0.0f,const PointerTourist& pt) {
            if(pt->type() == TouristVehicleType::CAB)
            {
                count++;
                return total + pt->perHourBookingCharges();
            }
            else
                return total;
        }
    );

    return sum/count;
}

std::string SerialOfMaxBookingCharge(Container &data)
{
    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerTourist& pt1,const PointerTourist& pt2) {
            return pt1->perHourBookingCharges() < pt2->perHourBookingCharges();
        }
    );

    return itr->get()->permit()->serialNumber();
}

Container FirstNInstance(Container &data, int N)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    Container result(data.size());

  auto itr = std::copy_n(data.begin(),N,result.begin());
  
  result.resize(std::distance(result.begin(),itr));

    return result;
}
