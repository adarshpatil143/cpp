#include<iostream>
#include "Permit.h"
#include "TouristVehicle.h"
#include "TouristVehicleType.h"
#include "PermitType.h"
#include<list>
#include<memory>
#include<numeric>
#include<algorithm>
#include "Functionalities.h"
#include<optional>


using TouristPointer = std::shared_ptr<TouristVehicle>;
using Container = std::list<TouristPointer>;

int main()
{
    Container data;

    try
    {
        CreateObject(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::optional<Container> result = InstanceConditionSatisfy(data);

        if(result.has_value())
        {
            for(auto i: result.value())
            {
                std::cout<<*i<<std::endl;
            }
        }
        else
        {
            std::cout<<"\nData is Empty"<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Average is: "<<AveragePerBooking(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Serial number of Charge Maximum: "<<SerialOfMaxBookingCharge(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        Container res2 = FirstNInstance(data,2);
        for(auto i: res2)
        {
            std::cout<<*i<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    
    
    
}