#ifndef TOURISTVEHICLE_H
#define TOURISTVEHICLE_H

#include<iostream>
#include "TouristVehicleType.h"
#include "Permit.h"
#include<memory>

using PermitPointer = std::shared_ptr<Permit>;

class TouristVehicle
{
private:
    std::string _number;
    TouristVehicleType _type;
    int _seat_count;
    float _per_hour_booking_charges;
    PermitPointer _permit;
public:
    TouristVehicle() =delete;
    TouristVehicle(const TouristVehicle&) = delete;
    TouristVehicle(TouristVehicle&&) = delete;
    TouristVehicle& operator=(TouristVehicle&) = delete;
    TouristVehicle& operator=(TouristVehicle&&) = delete;
    ~TouristVehicle() = default;

    TouristVehicle(std::string _number,TouristVehicleType _type,int _seat_count,float _per_hour_booking_charges,PermitPointer _permit);

    std::string number() const { return _number; }

    TouristVehicleType type() const { return _type; }

    int seatCount() const { return _seat_count; }

    float perHourBookingCharges() const { return _per_hour_booking_charges; }

    PermitPointer permit() const { return _permit; }

    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);

};

std::string DisplayTouristType(TouristVehicleType type);

#endif // TOURISTVEHICLE_H
