#include"Functionalities.h"
#include<algorithm>
#include<numeric>

using RoomPointer = std::shared_ptr<Room>;
using RoomContainter = std::array< RoomPointer , 3>;

using HotelPointer = std::shared_ptr<Hotel>;
using HotelContainer = std::unordered_map< int , HotelPointer> ;


 /*
    A  function to create 4 instances of HOTEL type in a container that
allows the following 
  ---1)ability to use iterators
  ---2)ability to use _location_code as label/key for amortized O(1) access

*/

void CreateObjects(HotelContainer& data){

    RoomContainter roomArray1;
    RoomContainter roomArray2;

    roomArray1[0] = std::make_shared<Room>(100.0f, RoomType::DELUX, 1000.0f, 150.0f);
    roomArray1[1] = std::make_shared<Room>(200.0f, RoomType::LUXURY, 2000.0f, 350.0f);
    roomArray1[2] = std::make_shared<Room>(300.0f, RoomType::MAPLE, 3000.0f, 450.0f);

    roomArray2[0] = std::make_shared<Room>(100.0f, RoomType::DELUX, 1000.0f, 150.0f);
    roomArray2[1] = std::make_shared<Room>(200.0f, RoomType::LUXURY, 2000.0f, 350.0f);
    roomArray2[2] = std::make_shared<Room>(300.0f, RoomType::MAPLE, 3000.0f, 450.0f);
    
    
    
    data.emplace(
        101,
        std::make_shared<Hotel>("h101", 100, 11, roomArray1, HotelCategory::MOTEL)
    );

    data.emplace(
        102,
        std::make_shared<Hotel>("h102", 102, 12, roomArray2, HotelCategory::PREMIUM)
    );

    data.emplace(
        103,
        std::make_shared<Hotel>("h103", 104, 13, roomArray1, HotelCategory::STAY)
    );

    data.emplace(
        104,
        std::make_shared<Hotel>("h104", 106, 14, roomArray2, HotelCategory::PREMIUM)
    );


}

/*
    A function to find the count of instances of HOTEL in the container that are 
    of PREMIUM category with at least 1 Room in the _rooms container of _type DELUX

*/

int CountInstances(HotelContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

     bool flag = false;

    int val = std::count_if(
        data.begin(),
        data.end(),
        [&](auto& obj){
            auto[key, h] = obj;
            std::for_each(
                h->rooms().begin(),
                h->rooms().end(),
                [&](RoomPointer& r){
                    if(r->type() == RoomType::DELUX){
                        flag = true;
                        return;
                    }
            }
            );
            return h->category() == HotelCategory::PREMIUM 
                        && flag == true;          
        }
    );

    return val;
}

// /*

//     A function that accepts container of HOTEL instances and a container of
//      ---_location_code values as parameters. The function must copy the instances 
//         whose _location_code matches the _location_code values recieved in the second parameter
     
// */

std::optional<HotelContainer> CopyInstances(HotelContainer &data, int code)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    HotelContainer result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [&](auto& obj){
            auto[key, h] = obj;
            return h->locationCode() == code;
        }
    );

    // result.resize(std::distance(result.begin(), itr));

    if(result.empty()){
        return std::nullopt;
    }

    return result;
    
}

// /*
// A function to find and return the average _area of Room instances for ONLY
// the HOTEL instances whose _location_code is passed as the second parameter 
// to the function
// */

float AverageAreaOfRoom(HotelContainer &data, int code)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    float total = 0.0f;

    bool flag = false;

    std::for_each(
        data.begin(),
        data.end(),
        [&](auto& obj){
            auto[key, h] = obj;
            if(h->locationCode() == code){
                flag = true;
                total = std::accumulate(
                    h->rooms().begin(),
                    h->rooms().end(),
                    0.0f,
                    [&](float ans, RoomPointer& r){
                        return ans += r->area();
                    }
                );
            }
        }
    );

    if(flag == false){
        throw std::runtime_error("Given code not present ");
    }

    return total;
}

// /*
//  A function to return N instances of HOTEL in a container whose _category
//  matches the second parameter recieved in the function
// */

HotelVector CopyNInstance(HotelContainer &data, HotelCategory cat)
{

    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    HotelVector result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [&](HotelPointer& h){
            return h->category() == cat;
        }
    );

    result.resize(std::distance(result.begin(), itr));

    return result;
}

// /*
//     A function to return boolean to indicate whether the a Hotel instance
//     exists in the data contanier whose _location_code passed as
//      the second parameter to the function
// */

bool FindHotelInstance(HotelContainer &data, int code)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    bool itr = std::any_of(
        data.begin(),
        data.end(),
        [&](auto& val){
            auto[key, h] = val;
            return h->locationCode() == code;
        }
    );

    return itr;
}
