enum class RoomType{
    DELUX,
    MAPLE,
    LUXURY

};