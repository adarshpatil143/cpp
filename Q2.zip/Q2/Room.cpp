#include "Room.h"
std::ostream &operator<<(std::ostream &os, const Room &rhs) {
    os << "_area: " << rhs._area
       << " _type: " << DisplayEnum(rhs._type)
       << " _price: " << rhs._price
       << " _tax_amount: " << rhs._tax_amount;
    return os;
}
std::string DisplayEnum(RoomType type)
{
    if(type == RoomType::DELUX){
        return "DELUX";
    }else if(type == RoomType::LUXURY){
        return "LUXURY";
    }else{
        return "MAPLE";
    }
}

Room::Room(float area, RoomType type, float price, float tax)
        : _area(area), _type(type), _price(price), _tax_amount(tax)
{
    if(type == RoomType::DELUX || type == RoomType::LUXURY){
        _tax_amount = 0.1 * _price;
    }else{
        _tax_amount = 0.15 * _price;
    }
}
