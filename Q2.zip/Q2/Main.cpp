#include"Functionalities.h"

#include<optional>


using RoomPointer = std::shared_ptr<Room>;
using RoomContainter = std::array< RoomPointer , 3>;

using HotelPointer = std::shared_ptr<Hotel>;
using HotelContainer = std::unordered_map< int , HotelPointer> ;

using HotelVector = std::vector<HotelPointer>;

using opt = std::optional<HotelContainer>;

int main(){

    HotelContainer data;

    CreateObjects(data);

    for(auto& [k,v] : data){
        std::cout << "key is: " << k << " ";
        std::cout << "value is: " << *v << "\n ";
    }

     std::cout << "Count instances: " << CountInstances(data) << "\n";

    opt result = CopyInstances(data, 100);

    if(result.has_value()){
        for(auto& val : result.value()){
            std::cout << val.second<< "\n";
        }
    }else{
        std::cout << "Result empty";
    }

    std::cout << AverageAreaOfRoom(data, 100) << "\n";

    std::cout << FindHotelInstance(data, 100) << "\n";



}