#include"Room.h"
#include"Hotel.h"
#include<iostream>
#include<unordered_map>
#include<optional>
#include<vector>

using RoomPointer = std::shared_ptr<Room>;
using RoomContainter = std::array< RoomPointer , 3>;

using HotelPointer = std::shared_ptr<Hotel>;
using HotelContainer = std::unordered_map< int , HotelPointer> ;

using HotelVector = std::vector<HotelPointer>;


 /*
    A  function to create 4 instances of HOTEL type in a container that
allows the following 
  ---1)ability to use iterators
  ---2)ability to use _location_code as label/key for amortized O(1) access

*/

void CreateObjects(HotelContainer& data);

/*
    A function to find the count of instances of HOTEL in the container that are 
    of PREMIUM category with at least 1 Room in the _rooms container of _type DELUX

*/

int CountInstances(HotelContainer& data);

/*

    A function that accepts container of HOTEL instances and a container of
     ---_location_code values as parameters. The function must copy the instances 
        whose _location_code matches the _location_code values recieved in the second parameter
     
*/

std::optional<HotelContainer> CopyInstances(HotelContainer& data, int code);

/*
A function to find and return the average _area of Room instances for ONLY
the HOTEL instances whose _location_code is passed as the second parameter 
to the function
*/

float AverageAreaOfRoom(HotelContainer& data, int code);

/*
 A function to return N instances of HOTEL in a container whose _category
 matches the second parameter recieved in the function
*/

HotelVector CopyNInstance(HotelContainer& data, HotelCategory cat);


/*
    A function to return boolean to indicate whether the a Hotel instance
    exists in the data contanier whose _location_code passed as
     the second parameter to the function
*/

bool FindHotelInstance(HotelContainer& data, int code);