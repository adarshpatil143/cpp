#include<iostream>
#include<array>
#include"HotelCategory.h"
#include<memory>
#include"Room.h"

using RoomPointer = std::shared_ptr<Room>;
using RoomContainter = std::array< RoomPointer , 3>;

class Hotel{
private:    
    std::string _value;
    int _location_code;
    int _unique_number;
    RoomContainter _rooms;
    HotelCategory _category;

public: 
    Hotel() = delete;                           // deleted default constructor
    Hotel(const Hotel &) = delete;             // deleted copy constructor
    Hotel &operator=(const Hotel &) = delete;  // deleted copy assignment operator
    Hotel &operator=(const Hotel &&) = delete; // deleted move assignment operator
    Hotel(Hotel &&) = delete;                  // deleted move constructor
    ~Hotel() = default;                         // enabled destructor

    Hotel(std::string value, int lcode, int unumber, RoomContainter rooms, HotelCategory cat);

    std::string value() const { return _value; }

    int locationCode() const { return _location_code; }

    int uniqueNumber() const { return _unique_number; }

    RoomContainter rooms() const { return _rooms; }

    HotelCategory category() const { return _category; }

    friend std::ostream &operator<<(std::ostream &os, const Hotel &rhs);
};

std::string DisplayEnum(HotelCategory htype);