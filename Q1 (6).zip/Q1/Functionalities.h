#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<array>
#include<memory>
#include"Car.h"
#include"inttypes.h"
#include<optional>
#include"vector"

using carPointer=std::shared_ptr<Car>;
using CarContainer=std::vector<carPointer>;
using InsPointer=std::shared_ptr<Insurance>;
using InsContainer=std::vector<InsPointer>;

void CreateObjects(CarContainer& carData,InsContainer& InsData);

/*
count
*/

int countInstance(CarContainer& data);

bool MatchCondition(CarContainer& data);

//matching segment instance

std::optional<CarContainer> SegmentMatchInstance(CarContainer& data,Segment tp);

//retrun pointer matching serialNumber

std::optional<carPointer> SerialNumberMatch(CarContainer& data,std::string sNumber);
//average

float AverageMatchingSegment(CarContainer& data,std::string br);


#endif // FUNCTIONALITIES_H
