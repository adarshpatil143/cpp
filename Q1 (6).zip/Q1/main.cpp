#include<iostream>
#include<array>
#include<memory>
#include"Car.h"
#include"inttypes.h"
#include"Functionalities.h"
#include"vector"

using carPointer=std::shared_ptr<Car>;
using CarContainer=std::vector<carPointer>;
using InsPointer=std::shared_ptr<Insurance>;
using InsContainer=std::vector<InsPointer>;

int main(){
    CarContainer carData;
    InsContainer insData;
    try
    {
         CreateObjects(carData,insData);

         //count 

         int count=countInstance(carData);
         std::cout<<"Count is:"<<count<<"\n";

         //conditionMatch

         bool res=MatchCondition(carData);
         if(res==true){
            std::cout<<"yes thre exist one Instance with matching condition\n";
         }else{
            std::cout<<"No any  Instance with matching condition\n";
         }
//matching segment
        std::optional<CarContainer> resultSegment=SegmentMatchInstance(carData,Segment::BUDGET);
        if(resultSegment.has_value()){
            for(auto& val:resultSegment.value()){
                std::cout<<*val<<"\n";
            }
        }else{
            std::cout<<"No data found\n";
        }

        //matchingSerialNumber
        std::cout<<"\n";
        std::optional<carPointer> ptr=SerialNumberMatch(carData,"ser300");

        if(ptr.has_value()){
            std::cout<<**ptr<<"\n";
        }
        else{
            std::cout<<"No matching serisl Number Found\n";
        }

        //average

        float avg=AverageMatchingSegment(carData,"Honda");

        if(avg==-1){
            std::cout<<"No matching Brand Instance found\n";
        }else{
            std::cout<<"average is:"<<avg<<"\n";
        }
    }

    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
   
}
