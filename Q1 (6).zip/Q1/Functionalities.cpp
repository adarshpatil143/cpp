#include "Functionalities.h"
#include<algorithm>
#include<numeric>


void CreateObjects(CarContainer &carData, InsContainer &InsData)
{

    InsData.push_back(std::make_shared<Insurance>(InsuranceType::ALL_INCLUSIVE,800.0f,60));
    InsData.push_back(std::make_shared<Insurance>(InsuranceType::ALL_INCLUSIVE,900.0f,50));
    InsData.push_back(std::make_shared<Insurance>(InsuranceType::REGULAR,700.0f,40));
    InsData.push_back(std::make_shared<Insurance>(InsuranceType::ZERO_DEBT,600.0f,70));
    InsData.push_back(std::make_shared<Insurance>(InsuranceType::ALL_INCLUSIVE,900.0f,4500000.0f));

    carData.push_back(std::make_shared<Car>("ser100","Honda",2.6f,InsData[0],5000000.0f,Segment::BUDGET));
    carData.push_back(std::make_shared<Car>("ser1200","maruti",3.0f,InsData[1],6000000.0f,Segment::BUDGET));
    carData.push_back(std::make_shared<Car>("ser300","Dzire",1.6f,InsData[2],7000000.0f,Segment::PREMIUM));
    carData.push_back(std::make_shared<Car>("ser400","hero",4.0f,InsData[3],8000000.0f,Segment::SPORTS));
    carData.push_back(std::make_shared<Car>("ser500","Honda",3.5f,InsData[4],9000000.0f,Segment::BUDGET));
}

int countInstance(CarContainer &data)
{
    auto count=std::count_if(data.begin(),data.end(),[](carPointer& ptr){
        return ptr->price()>6000000.0f && ptr->segment()==Segment::BUDGET &&
         ptr->policy()->idvAmount()>=0.5*ptr->price();
    });

    return count;
}

bool MatchCondition(CarContainer &data)
{
    auto itr=std::any_of(data.begin(),data.end(),[](carPointer& ptr){
        return ptr->policy()->type()==InsuranceType::ZERO_DEBT &&
        ptr->policy()->premium()<15000.0f &&
        ptr->size()>2.0f;
    });

    return itr;
}

std::optional<CarContainer> SegmentMatchInstance(CarContainer &data, Segment tp)
{
   CarContainer result(data.size());

   auto itr=std::copy_if(data.begin(),data.end(),result.begin(),[&](carPointer& ptr){
    return ptr->segment()==tp;
   });

   result.resize(std::distance(result.begin(),itr));
   if(result.empty()){
    return std::nullopt;
   }

   else {
    return result;
   }

}

std::optional<carPointer> SerialNumberMatch(CarContainer &data, std::string sNumber)
{
   if( auto itr=std::find_if(data.begin(),data.end(),[&](carPointer& ptr){
        return ptr->serialNumber()==sNumber;
    }); itr!=data.end()){
        return *itr;
    }
    else{
        return std::nullopt;
    }


}

float AverageMatchingSegment(CarContainer &data, std::string br)
{
    float val;
    float sum=0.0f;
    int count=0;

   sum=std::accumulate(data.begin(),data.end(),0.0f,[&](float total,carPointer& ptr){
    if(ptr->brand()==br){
        ++count;
        val=ptr->price();
    }
    return total+val;
   });

   if(sum==0.0f){
    return -1;
   }
   else{
    return sum/count;
   }
}
