#ifndef CAR_H
#define CAR_H

#include <memory>
#include <iostream>
#include "Insurance.h"
#include "Segment.h"

using InsurancePolicy = std::shared_ptr<Insurance>;

class Car
{
private:
    std::string _serialNumber;
    std::string _brand;
    float _size;
    InsurancePolicy _policy;
    float _price;
    Segment _segment;
    float _tax;

public:
    Car(std::string serialNumber,
        std::string brand,
        float size,
        InsurancePolicy policy,
        float price,
        Segment segment)
        
        ;
    Car() = delete;
    Car(const Car &) = delete;
    Car(Car &&) = delete;
    Car &operator=(const Car &) = delete;

    Car &operator=(Car &&) = delete;

    ~Car() = default;

    float price() const { return _price; }

    Segment segment() const { return _segment; }

    InsurancePolicy policy() const { return _policy; }

    float size() const { return _size; }

    std::string serialNumber() const { return _serialNumber; }

    std::string brand() const { return _brand; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

std::string DisplaySegment(Segment tp);
#endif // CAR_H
