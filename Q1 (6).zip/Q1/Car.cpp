#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_serialNumber: " << rhs._serialNumber
       << " _brand: " << rhs._brand
       << " _size: " << rhs._size
       << " _policy: " << *rhs._policy
       << " _price: " << rhs._price
       << " _segment: " << DisplaySegment(rhs._segment)
       << " _tax: " << rhs._tax;
    return os;
}
std::string DisplaySegment(Segment tp)
{
   if(tp==Segment::BUDGET){
    return "BUDGET";
   }else if(tp==Segment::PREMIUM){
    return "PREMIUM";
   }else{
    return "SPORTS";
   }
}
Car::Car(std::string serialNumber, std::string brand, float size, InsurancePolicy policy, float price, Segment segment)
    : _serialNumber(serialNumber), _brand(brand), _policy(policy), _price(price), _segment(segment),_size(size)
{
    _tax=0.05*_price;
//    if(_policy->premium()>_tax){
//     throw std::runtime_error("invalid Premium Price\n");
//    }
}
