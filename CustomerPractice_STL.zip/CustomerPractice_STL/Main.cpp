
#include<algorithm>
#include<numeric>
#include<optional>
#include"Functionalities.h"

using CustomerPointer = std::shared_ptr<Customer>;
using CustomerContainer = std::vector<CustomerPointer>;

using opt = std::optional<CustomerContainer>;

int main(){
    CustomerContainer data;
    CreateObjects(data);
    for(auto& a : data){
        std::cout << *a << "\n";
    }

    std::cout << "---------------------------------------------------------------------------------- \n";
    
    std::cout << "\n Customer Id with highest store credits: " << FindCustomerId(data) << "\n";

    std::cout << "---------------------------------------------------------------------------------- \n";

    CustomerContainer result;
    result = FindCustomerWithGivenType(data, CustomerType::PREMIUM);
    std::cout << "\n Customer with given type: ";
    for(auto& val : result){
        std::cout << *val << "\n";
    }

    std::cout << "---------------------------------------------------------------------------------- \n";

    // CustomerContainer res;
    opt res = FindCustomerWithGivenRange(data);
    if(res.has_value()){
        for(auto& val : res.value()){
            std::cout << val << "\n";
        }
    }else{
        std::cout << "\n Result container is empty \n";
    }

    std::cout << "---------------------------------------------------------------------------------- \n";

    FindHighestLowestStoreCredit(data);

        std::cout << "---------------------------------------------------------------------------------- \n";

    FindAverageOfGivenType(data, CustomerType::PREMIUM);

        std::cout << "---------------------------------------------------------------------------------- \n";

    CheckAllInstancesoGivenType(data, CustomerType::REGULAR);

        std::cout << "---------------------------------------------------------------------------------- \n";

        std::cout <<"Customer satisfying given condition: " << FindCustomerInstancesWithGivenCondition(data) << "\n";
    
}