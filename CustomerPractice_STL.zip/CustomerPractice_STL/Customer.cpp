#include "Customer.h"

std::string DisplayEnum(CustomerType type)
{
    if(type == CustomerType::PREMIUM){
        return "PREMIUM";
    }else if(type == CustomerType::REGULAR){
        return "REGULAR";
    }else{
        return "VIP";
    }
}
Customer::Customer(int cid, std::string cname, CustomerType type, TransactionContainer tamount, float storecredit, std::shared_ptr<Account> caccount)
    : customerid(cid), customerName(cname), ctype(type), customerTransactionAmounts(tamount), customerStoreCredits(storecredit), customerAccount(caccount)
{
}

Customer::Customer(int cid)
            : customerid(cid)
{
}

float Customer::operator+(Customer &c1)
{
    return this->customerStoreCredits + c1.customerStoreCredits;
}

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "customerid: " << rhs.customerid
       << " customerName: " << rhs.customerName
       << " ctype: " << DisplayEnum(rhs.ctype)
       << " customerTransactionAmounts: ";
       for(auto& val : rhs.customerTransactionAmounts){
        os << val;
       }
    os   << " customerStoreCredits: " << rhs.customerStoreCredits
       << " customerAccount: " << *rhs.customerAccount;
    return os;
}
