#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include"Account.h"
#include"Customer.h"
#include<memory>
#include<list>
#include<vector>
#include<optional>

// using AccountPointer = std::shared_ptr<Account>;
// using AccountContainer = std::vector<AccountPointer>;

using CustomerPointer = std::shared_ptr<Customer>;
using CustomerContainer = std::vector<CustomerPointer>;

/*
    A function to create objects of customer type which have particular account
*/
void CreateObjects(CustomerContainer& data);

/*
    A function to find customer id of the customer whose combined customertransactionamount value is the
    highest
*/

int FindCustomerId(CustomerContainer& data);

/*
    A function to find and return a container of customer objects whose customer type matches the type passed as the second 
    argument
*/

CustomerContainer FindCustomerWithGivenType(CustomerContainer& data, CustomerType type);

/*
    A function to return a container of all customer instances whose customer store credits are between
    100 and 200(both values included) and _balance in customer account is over 500
*/

std::optional<CustomerContainer> FindCustomerWithGivenRange(CustomerContainer& data);

/*
    A function to find the customer instance with lowest and highest customer store credits and print
    the combined value for these credits on the standard output
*/

void FindHighestLowestStoreCredit(CustomerContainer& data);

/*
    A function to find average customer store credits of all customers whose customer type matches 
    the type provided in second argument
*/

void FindAverageOfGivenType(CustomerContainer& data, CustomerType type);

/*
    A function to find if all customer instances in a container are of customer type passed as the 
    second argument
*/

void CheckAllInstancesoGivenType(CustomerContainer& data, CustomerType type);

/*
    A function to find and return the count of customer instances whose customer type is REGULAR
    and customeraccount balance is over 1000
*/

int FindCustomerInstancesWithGivenCondition(CustomerContainer& data);

#endif // FUNCTIONALITIES_H
