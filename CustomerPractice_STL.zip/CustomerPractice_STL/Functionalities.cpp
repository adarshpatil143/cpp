#include<algorithm>
#include<numeric>
#include<optional>
#include "Functionalities.h"

/*
    STL ALGORITHM: STD::ADVANCE => used to iterate(list me aage peeche jaana) through the list(specifically)
        std::advance(itr, 3);  => moving the begin index of list by 3 position
*/

using AccountPointer = std::shared_ptr<Account>;
using AccountContainer = std::vector<AccountPointer>;

using CustomerPointer = std::shared_ptr<Customer>;
using CustomerContainer = std::vector<CustomerPointer>;

void CreateObjects(CustomerContainer &data)
{

    data.push_back(std::make_shared<Customer>(111, "Gurmeet", CustomerType::PREMIUM, std::array<float, 5> {10, 20, 30, 40, 50}, 60.0f, std::make_shared<Account>("101", 45000.0f)));
    data.push_back(std::make_shared<Customer>(112, "Rohan", CustomerType::REGULAR, std::array<float, 5> {5, 10, 8, 15, 18}, 50.0f, std::make_shared<Account>("102", 55000.0f)));
    data.push_back(std::make_shared<Customer>(113, "Riya", CustomerType::VIP, std::array<float, 5> {6, 16, 18, 10, 15}, 70.0f, std::make_shared<Account>("102", 55000.0f)));

}

/*
    A function to find customer id of the customer whose combined customertransactionamount value is the
    highest
*/

int FindCustomerId(CustomerContainer &data)
{
    int i = 0;

    std::vector<float> sumArray;

    for(auto& val : data){
        auto sum = std::accumulate(
        val->getCustomerTransactionAmounts().begin(),
        val->getCustomerTransactionAmounts().end(),
        0.0f,
        [](float ans, float& value){
            return ans + value;
        }
    );
    sumArray.push_back(sum);
    i++;
    }
    

    auto itr = std::max_element(
        sumArray.begin(),
        sumArray.end()
    );

  int index = std::distance(sumArray.begin(), itr);

   return data[index]->getCustomerid();

}

/*
    A function to find and return a container of customer objects whose customer type matches the type passed as the second 
    argument
*/

CustomerContainer FindCustomerWithGivenType(CustomerContainer &data, CustomerType type)
{
    CustomerContainer result;

// STL ALGORITHM : STD::FIND(NOT COMPILING)
    // for(auto& val : data){
    //     auto itr = std::find(
    //         data.begin(),
    //         data.end(),
    //         [&](CustomerPointer& c){
    //             return c->getCtype() == type;
    //         }
    //     );
    //     result.push_back(*itr);
    // }

//STL ALGORITHM : STD::FOR_EACH
    std::for_each(
        data.begin(),
        data.end(),
        [&](CustomerPointer& c){
            if(c->getCtype() == type){
                result.push_back(c);
            }
        }
    );

    return result;

}

/*
    A function to return a container of all customer instances whose customer store credits are between
    100 and 200(both values included) and _balance in customer account is over 500
*/

std::optional<CustomerContainer> FindCustomerWithGivenRange(CustomerContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("Data Empty!! \n");
    }

    CustomerContainer result;
    // for(auto& val : data){
        if(auto itr = std::find_if(
            data.begin(),
            data.end(),
            [&](CustomerPointer& c){
                return c->getCustomerStoreCredits() >= 100 && c->getCustomerStoreCredits() <= 200 && c->getCustomerAccount()->balance() > 500;
            }
        ); itr != data.end()){
            result.push_back(*itr);
        }
        // result.push_back(*itr);
    // }

    if(result.empty()){
        return std::nullopt;
    }

    return result;
}

void FindHighestLowestStoreCredit(CustomerContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("DATA EMPTY \n");
    }

    std::sort(
        data.begin(),
        data.end(),
        [](CustomerPointer& c1, CustomerPointer& c2){
            return c1->getCustomerStoreCredits() > c2->getCustomerStoreCredits();
        }
    );

    int max = data[data.size()-1].get()->getCustomerStoreCredits();
    int min = data[0].get()->getCustomerStoreCredits();

    std::cout << "Sum of maximum & minimum store credits: " << max + min << "\n";
}

void FindAverageOfGivenType(CustomerContainer &data, CustomerType type)
{

    CustomerContainer typeresult;


    if(auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](CustomerPointer& c){
            return (c->getCtype() == type);
        }
    ); itr != data.end()){
        typeresult.push_back(*itr);
    }

    float sum = std::accumulate(
        typeresult.begin(),
        typeresult.end(),
        0.0f,
        [](float res, CustomerPointer& val){
            return res + val->getCustomerStoreCredits();
        }
    );

    std::cout << "Average is: " << sum/typeresult.size() << "\n";

}

void CheckAllInstancesoGivenType(CustomerContainer &data, CustomerType type)
{
    auto itr = std::all_of(
        data.begin(),
        data.end(),
        [&](CustomerPointer& c){
            return c->getCtype() == type;
        }
    );

    std::cout << "All instances of given type present in the container: ";
    if(itr == 0){
        std::cout << false << "\n";
    }else{
        std::cout << true << "\n";
    }
}

int FindCustomerInstancesWithGivenCondition(CustomerContainer &data)
{

    int res = std::count_if(
        data.begin(),
        data.end(),
        [](CustomerPointer& c){
            return (c->getCtype() == CustomerType::REGULAR && c->getCustomerAccount().get()->balance() > 1000);
        }
    );

    return res;

}
