#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include"CustomerType.h"
#include"Account.h"
#include<array>
#include<memory>

using TransactionContainer = std::array<float, 5>;


class Customer{
private:    
    int customerid;
    std::string customerName;
    CustomerType ctype;
    TransactionContainer customerTransactionAmounts;
    float customerStoreCredits;
    std::shared_ptr<Account> customerAccount;

public:
    Customer() = delete;
    Customer(const Customer&) = delete;
    Customer(Customer&&) = delete;
    Customer& operator=(const Customer&) = delete;
    Customer& operator=(const Customer&&) = delete;
    ~Customer() = default;

    Customer(int cid, std::string cname, CustomerType type, TransactionContainer tamount, float storecredit, std::shared_ptr<Account> caccount);

    explicit Customer(int cid);


    float operator+(Customer& c1);

    int getCustomerid() const { return customerid; }

    std::string getCustomerName() const { return customerName; }

    CustomerType getCtype() const { return ctype; }

    TransactionContainer getCustomerTransactionAmounts() const { return customerTransactionAmounts; }

    float getCustomerStoreCredits() const { return customerStoreCredits; }

    std::shared_ptr<Account> getCustomerAccount() const { return customerAccount; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);

    

};

std::string DisplayEnum(CustomerType type);

#endif // CUSTOMER_H
