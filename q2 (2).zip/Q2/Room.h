#ifndef ROOM_H
#define ROOM_H

#include<iostream>
#include"RoomType.h"

class Room{
private:
    float _area;
    RoomType _type;
    float _price;
    float _tax_amount;

public:
    Room() = delete;                           // deleted default constructor
    Room(const Room &) = delete;             // deleted copy constructor
    Room &operator=(const Room &) = delete;  // deleted copy assignment operator
    Room &operator=(const Room &&) = delete; // deleted move assignment operator
    Room(Room &&) = delete;                  // deleted move constructor
    ~Room() = default;                         // enabled destructor

    Room(float area, RoomType type, float price, float tax);

    float area() const { return _area; }

    RoomType type() const { return _type; }

    float price() const { return _price; }

    float taxAmount() const { return _tax_amount; }

    friend std::ostream &operator<<(std::ostream &os, const Room &rhs);

    

};

std::string DisplayEnum(RoomType type);

#endif // ROOM_H
