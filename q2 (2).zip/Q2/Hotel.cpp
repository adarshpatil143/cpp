#include "Hotel.h"
std::ostream &operator<<(std::ostream &os, const Hotel &rhs) {
    os << "_value: " << rhs._value
       << " _location_code: " << rhs._location_code
       << " _unique_number: " << rhs._unique_number
       << " _rooms: ";
       for(auto& val : rhs._rooms){
        std::cout << *val;
       }
    os  << " _category: " << DisplayEnum(rhs._category);
    return os;
}
std::string DisplayEnum(HotelCategory htype)
{
    if(htype == HotelCategory::MOTEL){
        return "MOTEL";
    }else if(htype == HotelCategory::PREMIUM){
        return "PREMIUM";
    }else{
        return "STAY";
    }
}

Hotel::Hotel(std::string value, int lcode, int unumber, RoomContainter rooms, HotelCategory cat)
        : _value(value), _location_code(lcode), _unique_number(unumber), _rooms(rooms), _category(cat)
{

}
