#ifndef HOTELCATEGORY_H
#define HOTELCATEGORY_H

enum class HotelCategory{
    PREMIUM,
    STAY,
    MOTEL
};

#endif // HOTELCATEGORY_H
