#include "Functionality.h"
using DevicePointer = std::shared_ptr<Device>;
using DeviceContainer = std::vector<std::shared_ptr<Device>>;
void CreateObject(DeviceContainer &data)
{
    data.push_back(std::make_shared<Device>("101", "Samsung Phone", 26000.0f, 2.0f, DeviceType::MOBILE));
    data.push_back(std::make_shared<Device>("102", "Ps4",760000.0f, 5.0f, DeviceType::WORKSTATION));
    data.push_back(std::make_shared<Device>("103", "Samsung Phone", 26000.0f, 6.0f, DeviceType::MOBILE));
    data.push_back(std::make_shared<Device>("104", "Samsung Phone", 26000.0f, 7.0f, DeviceType::MOBILE));
    data.push_back(std::make_shared<Device>("105", "Samsung Phone", 26000.0f, 8.0f, DeviceType::MOBILE));
}

void showResult(DeviceContainer &data)
{

    for(auto it:data)
    {
        std::cout<<*it<<std::endl;
    }
}
//discount price//
void DiscountedPrice(DevicePointer instances)
{
    float discountPrice = 0.0f;
     if( instances->type() == DeviceType::ACCESORY || instances->type() == DeviceType::WORKSTATION  )
     {
       discountPrice=  instances->price() * 0.01f;
     }
     else{
        discountPrice=  instances->price() * 0.02f;
     }
     std::cout<<"Discounted Price of Device is :"<<discountPrice<<std::endl;
}

void FinTaxAmount(DevicePointer instances)
{
     float FinTax = 0.0f;
    if(instances->sarValue()>=1.0 && instances->sarValue()>=1.5 )
    {
        FinTax = instances->price()*0.18f;
    }
    else if(instances->sarValue()>=1.5 && instances->sarValue()>=2.0 )
    {
        FinTax = instances->price()*0.18f;
    }
    std::cout<<"Fin Tax Amount"<<FinTax;
}
