#ifndef DEVICE_H
#define DEVICE_H

#include <iostream>
#include "DeviceType.h"

class Device
{
private:
    /* data */
    std::string _id;
    std::string _name;
    float _price;
    float _sar_value = 1.0f;
    DeviceType _type;

public:
    Device() = delete;                         // DEFAULT constructor is enabled
    Device(const Device &) = delete;            // COPY constructor is disabled
    Device(Device &&) = delete;                 // Move constructor is disabled
    Device &operator=(const Device &) = delete; // assignment overload is disabled
    Device &operator=(Device &&) = delete;      // move assignment is disabled
    ~Device() = default;                        // destructor is enabled

    // parametrized Constructor
    Device(std::string id,std::string name,float price,float sar_value,DeviceType dtype);

    std::string id() const {return _id;}

    std::string name() const { return _name; }

    float price() const { return _price; }

    float sarValue() const { return _sar_value; }

    DeviceType type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const Device &rhs);

    
};
std::string DisplayEnum(DeviceType type);
#endif // DEVICE_H
