#ifndef FUNCTIONALITY_H
#define FUNCTIONALITY_H

#include<iostream>
#include"Device.h"
#include<memory>
#include<vector>

using DevicePointer = std::shared_ptr<Device>;
using DeviceContainer = std::vector<std::shared_ptr<Device>>;
//functionaity defination//

//creating a function to create a five object//
void CreateObject(DeviceContainer &data);


void showResult(DeviceContainer &data);

//a function that accepts single device instances and print it discounted price//
void DiscountedPrice(DevicePointer instances);
//if type is MOBILE and WorkStation discount Price is 10% of the device
//if type is accesories discount 20%


//accept a single instances and print//
//if sar value between is 1.0 to 1.5 tax amount is 18%
//if sar value between 1.5 to 2.0 tax is 18%

void FinTaxAmount(DevicePointer instances);







#endif // FUNCTIONALITY_H
