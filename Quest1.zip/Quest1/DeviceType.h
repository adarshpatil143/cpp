#ifndef DEVICETYPE_H
#define DEVICETYPE_H

#include<iostream>

enum class DeviceType{
    MOBILE=1,
    WORKSTATION=2,
    ACCESORY
};

#endif // DEVICETYPE_H
