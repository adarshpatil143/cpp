#include"Device.h"
#include<iostream>

std::string DisplayEnum(DeviceType type)
{
    if(type == DeviceType::ACCESORY)
    return "Accesory";
    else if(type == DeviceType::MOBILE)
    return "Mobile";
    else
    return "WorkStation";

}


Device::Device(std::string id, std::string name, float price, float sar_value, DeviceType dtype)
:_id(id),_name(name),_price(price),_sar_value(sar_value),_type(dtype)
{
    if(sar_value <=2.0 && sar_value>=10.0f)
    std::runtime_error("Sar value should be in range of 2.0 -- 10.0");
}

std::ostream &operator<<(std::ostream &os, const Device &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _price: " << rhs._price
       << " _sar_value: " << rhs._sar_value
       << " _type: " << DisplayEnum(rhs._type);
    return os;
}
