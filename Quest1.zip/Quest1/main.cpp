#include <iostream>
#include "Functionality.h"
#include "Device.h"
#include "DeviceType.h"
using DevicePointer = std::shared_ptr<Device>;
using DeviceContainer = std::vector<std::shared_ptr<Device>>;

int main()
{
    DeviceContainer DeviceData;
    // create 5 objects//
    CreateObject(DeviceData);

    // show data
    showResult(DeviceData);

    // accept single device object and print the discounted price;
    DiscountedPrice(DeviceData[0]);

    FinTaxAmount(DeviceData[0]);

    auto f1 = [](DevicePointer instances)
    {
        std::cout << "SAR Value is:" << instances->sarValue() << std::endl;
        std::cout << "Price is:" << instances->price() << std::endl;
    };

    f1(DeviceData[0]);

    auto f2 = [](DevicePointer instances)
    {
        if (instances->type() == DeviceType::MOBILE)
        {
            std::cout << "Id of passed type is" << instances->id() << std::endl;
        }
        else if (instances->type() == DeviceType::WORKSTATION)
        {
            std::cout << "Name of Passed type is" << instances->name() << std::endl;
        }
        else
        {
            std::cout << "Name of Passed type is" << instances->sarValue() << std::endl;
        }
    };

    f2(DeviceData[0]);

    FinTaxAmount(DeviceData[0]);
}